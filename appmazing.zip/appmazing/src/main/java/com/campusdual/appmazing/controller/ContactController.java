package com.campusdual.appmazing.controller;

import com.campusdual.appmazing.api.IContactService;
import com.campusdual.appmazing.model.dto.ContactDTO;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController()
@RequestMapping("/contacts")
public class ContactController {

    @Autowired
    private IContactService contactService;
    @GetMapping
    public String testContactController(){

        return "También va la de contactos¡¡¡";
    }
    @PostMapping(value = "/get")
    public ContactDTO queryContact(@RequestBody ContactDTO contactDTO){
        return contactService.queryContact(contactDTO);
    }
    @GetMapping(value = "/getAll")
    public List<ContactDTO> queryAllContacts(){
        return contactService.queryAllContacts();
    }
    @PostMapping(value = "/add")
    public int addContact(@RequestBody ContactDTO contactDTO){
        return contactService.insertContact(contactDTO);
    }
    @PutMapping(value = "/update")
    public int updateContact(@RequestBody ContactDTO contactDTO){
        return contactService.updateContact(contactDTO);
    }
    @DeleteMapping(value = "/delete")
    public int deleteContact(@RequestBody ContactDTO contactDTO){
        return contactService.deleteContact(contactDTO);
    }
}
