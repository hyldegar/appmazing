package com.campusdual.appmazing;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AppmazingApplication {

	public static void main(String[] args) {
		SpringApplication.run(AppmazingApplication.class, args);
	}

}
