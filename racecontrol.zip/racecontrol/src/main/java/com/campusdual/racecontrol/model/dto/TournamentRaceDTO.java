package com.campusdual.racecontrol.model.dto;

import com.campusdual.racecontrol.model.Race;
import com.campusdual.racecontrol.model.Tournament;
import com.campusdual.racecontrol.model.TournamentRaceId;

public class TournamentRaceDTO {
    private TournamentRaceId id;
    private Tournament tournament;
    private Race race;

    public TournamentRaceId getId() {
        return id;
    }

    public void setId(TournamentRaceId id) {
        this.id = id;
    }

    public Tournament getTournament() {
        return tournament;
    }

    public void setTournament(Tournament tournament) {
        this.tournament = tournament;
    }

    public Race getRace() {
        return race;
    }

    public void setRace(Race race) {
        this.race = race;
    }
}
