package com.campusdual.racecontrol.model.dto.dtomapper;

import com.campusdual.racecontrol.model.RacesGarages;
import com.campusdual.racecontrol.model.dto.RacesGaragesDTO;
import org.mapstruct.factory.Mappers;

import java.util.List;

public interface RacesGaragesMapper {
    RacesGaragesMapper INSTANCE = Mappers.getMapper(RacesGaragesMapper.class);
    RacesGaragesDTO toDTO (RacesGarages racesGarages);
    List<RacesGaragesDTO> toDTOList(List<RacesGarages> racesGarages);
    RacesGarages toEntity(RacesGaragesDTO racesGaragesdto);
}
