package com.campusdual.racecontrol.api;

import com.campusdual.racecontrol.model.dto.GarageDTO;

import java.util.List;

public interface IGarageService {
    GarageDTO queryGarage(GarageDTO garageDTO);
    List<GarageDTO> queryAllGarages();

    int insertGarage(GarageDTO garageDTO);
    int updateGarage(GarageDTO garageDTO);
    int deleteGarage(GarageDTO garageDTO);

    GarageDTO getGarageById(int id);
}
