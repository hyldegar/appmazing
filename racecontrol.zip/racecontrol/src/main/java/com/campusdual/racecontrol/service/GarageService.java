package com.campusdual.racecontrol.service;

import com.campusdual.racecontrol.api.IGarageService;
import com.campusdual.racecontrol.model.Garage;
import com.campusdual.racecontrol.model.dao.GarageDao;
import com.campusdual.racecontrol.model.dto.GarageDTO;
import com.campusdual.racecontrol.model.dto.dtomapper.GarageMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Lazy;
import org.springframework.stereotype.Service;

import java.util.List;

@Service("GarageService")
@Lazy
public class GarageService implements IGarageService {
    @Autowired
    private GarageDao garageDao;
    @Override
    public GarageDTO queryGarage(GarageDTO garageDTO) {

        Garage garage= GarageMapper.INSTANCE.toEntity(garageDTO);
        return GarageMapper.INSTANCE.toDTO(this.garageDao.getReferenceById(garage.getId()));
    }

    @Override
    public List<GarageDTO> queryAllGarages() {
        return GarageMapper.INSTANCE.toDTOList(this.garageDao.findAll());
    }

    @Override
    public int insertGarage(GarageDTO garageDTO) {
        Garage garage=GarageMapper.INSTANCE.toEntity(garageDTO);
        garageDao.saveAndFlush(garage);
        return garage.getId();
    }

    @Override
    public int updateGarage(GarageDTO garageDTO) {
        return insertGarage(garageDTO);
    }

    @Override
    public int deleteGarage(GarageDTO garageDTO) {
        Garage garage=GarageMapper.INSTANCE.toEntity(garageDTO);
        garageDao.delete(garage);
        return garageDTO.getId();
    }

    @Override
    public GarageDTO getGarageById(int id) {
        Garage garage = garageDao.findById(id).orElse(null);
        return GarageMapper.INSTANCE.toDTO(garage);
    }


}
