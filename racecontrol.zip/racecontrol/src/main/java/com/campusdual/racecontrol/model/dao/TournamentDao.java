package com.campusdual.racecontrol.model.dao;

import com.campusdual.racecontrol.model.Tournament;
import org.springframework.data.jpa.repository.JpaRepository;

public interface TournamentDao extends JpaRepository<Tournament,Integer> {
}
