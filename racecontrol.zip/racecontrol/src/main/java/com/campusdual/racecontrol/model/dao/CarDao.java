package com.campusdual.racecontrol.model.dao;

import com.campusdual.racecontrol.model.Car;
import org.springframework.data.jpa.repository.JpaRepository;

public interface CarDao extends JpaRepository<Car, Integer> {

}
