package com.campusdual.racecontrol.model;

import javax.persistence.*;

@Entity
@Table(name = "TOURNAMENT_RACES")
public class TournamentRace {
    @EmbeddedId
    private TournamentRaceId id;

    @ManyToOne
    @JoinColumn(name = "TOURNAMENT_ID", insertable = false, updatable = false)
    private Tournament tournament;

    @ManyToOne
    @JoinColumn(name = "RACE_ID", insertable = false, updatable = false)
    private Race race;

    public TournamentRaceId getId() {
        return id;
    }

    public void setId(TournamentRaceId id) {
        this.id = id;
    }

    public Tournament getTournament() {
        return tournament;
    }

    public void setTournament(Tournament tournament) {
        this.tournament = tournament;
    }

    public Race getRace() {
        return race;
    }

    public void setRace(Race race) {
        this.race = race;
    }


}

