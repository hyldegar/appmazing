package com.campusdual.racecontrol.api;

import com.campusdual.racecontrol.model.RacesGaragesId;
import com.campusdual.racecontrol.model.dto.RacesGaragesDTO;

import java.util.List;

public interface IRacesGaragesService {
    RacesGaragesDTO queryRacesGarages(RacesGaragesDTO racesGaragesDTO);
    List<RacesGaragesDTO> queryAllRacesGarages();

    RacesGaragesId insertRacesGarages(RacesGaragesDTO racesGaragesDTO);
    RacesGaragesId updateRacesGarages(RacesGaragesDTO racesGaragesDTO);
    RacesGaragesId deleteRacesGarages(RacesGaragesDTO racesGaragesDTO);
}
