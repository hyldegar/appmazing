package com.campusdual.racecontrol.api;

import com.campusdual.racecontrol.model.dto.CarDTO;

import java.util.List;

public interface ICarService {
    //CRUD Operations

    CarDTO queryCar(CarDTO carDTO);
    List<CarDTO> queryAllCars();
    int insertCar(CarDTO carDTO);
    int updateCar(CarDTO carDTO);
    int deleteCar(CarDTO carDTO);
}
