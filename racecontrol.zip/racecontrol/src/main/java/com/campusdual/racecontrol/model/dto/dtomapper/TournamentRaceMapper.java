package com.campusdual.racecontrol.model.dto.dtomapper;

import com.campusdual.racecontrol.model.TournamentRace;

import com.campusdual.racecontrol.model.dto.TournamentRaceDTO;
import org.mapstruct.Mapper;
import org.mapstruct.factory.Mappers;

import java.util.List;
@Mapper
public interface TournamentRaceMapper {
    TournamentRaceMapper INSTANCE= Mappers.getMapper(TournamentRaceMapper.class);
    TournamentRaceDTO toDTO (TournamentRace tournamentRace);
    List<TournamentRaceDTO> toDTOList(List<TournamentRace> tournamentRaces);
    TournamentRace toEntity(TournamentRaceDTO tournamentRacedto);
}
