package com.campusdual.racecontrol.model.dto;


public class RacesGaragesDTO {
    private Integer raceId;
    private Integer garageId;

    public Integer getRaceId() {
        return raceId;
    }

    public void setRaceId(Integer raceId) {
        this.raceId = raceId;
    }

    public Integer getGarageId() {
        return garageId;
    }

    public void setGarageId(Integer garageId) {
        this.garageId = garageId;
    }

    // Constructores, getters y setters
}