package com.campusdual.racecontrol.controller;

import com.campusdual.racecontrol.api.ICarService;
import com.campusdual.racecontrol.api.IGarageService;
import com.campusdual.racecontrol.model.dto.GarageDTO;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController()
@CrossOrigin(origins = "http://localhost:4200", methods = {RequestMethod.GET, RequestMethod.POST, RequestMethod.PUT,
        RequestMethod.DELETE, RequestMethod.OPTIONS}, allowedHeaders = "*")
@RequestMapping("/garages")
public class GarageController {
    @Autowired
    private IGarageService garageService;

    @GetMapping
    public String testGarageController(){
        return "Garage Controller Works¡¡¡";
    }
    @PostMapping
    public String testCarController(@RequestBody String name){
        return "Garage controller works, "+name+"!";
    }
    @GetMapping(value ="/testMethod")
    public String testControllerMethod(){
        return "Products controller method works!";
    }
    @PostMapping(value="/get")
    public GarageDTO queryGarage(@RequestBody GarageDTO garageDTO){
        return  garageService.queryGarage(garageDTO);
    }
    @GetMapping(value="/getAll")
    public List<GarageDTO> queryAllGarages(){
        return garageService.queryAllGarages();
    }
    @PostMapping(value="/add")
    public int addGarage(@RequestBody GarageDTO garageDTO){
        return garageService.insertGarage(garageDTO);
    }
    @PutMapping(value="/update")
    public int updateGarage(@RequestBody GarageDTO garageDTO){
        return garageService.updateGarage(garageDTO);
    }
    @PostMapping(value = "/delete")
    public int deleteGarage(@RequestBody GarageDTO garageDTO){
        return garageService.deleteGarage(garageDTO);
    }

    @GetMapping("/{id}")
    public ResponseEntity<GarageDTO> getGarageById(@PathVariable int id) {
        GarageDTO garageDTO = garageService.getGarageById(id);
        if (garageDTO != null) {
            return ResponseEntity.ok(garageDTO);
        } else {
            return ResponseEntity.notFound().build();
        }
    }

}
