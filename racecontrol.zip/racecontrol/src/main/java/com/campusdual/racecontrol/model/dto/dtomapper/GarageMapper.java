package com.campusdual.racecontrol.model.dto.dtomapper;

import com.campusdual.racecontrol.model.Garage;
import com.campusdual.racecontrol.model.dto.GarageDTO;
import org.mapstruct.Mapper;
import org.mapstruct.factory.Mappers;

import java.util.List;

@Mapper
public interface GarageMapper {
    GarageMapper INSTANCE = Mappers.getMapper(GarageMapper.class);
    GarageDTO toDTO (Garage garage);

    List<GarageDTO> toDTOList(List<Garage> garages);
    Garage toEntity(GarageDTO garagedto);


}
