package com.campusdual.racecontrol.model;

import javax.persistence.Column;
import javax.persistence.Embeddable;
import java.io.Serializable;

@Embeddable
public class TournamentRaceId implements Serializable {
    @Column(name = "TOURNAMENT_ID")
    private Integer tournamentId;

    @Column(name = "RACE_ID")
    private Integer raceId;

    public Integer getTournamentId() {
        return tournamentId;
    }

    public void setTournamentId(Integer tournamentId) {
        this.tournamentId = tournamentId;
    }

    public Integer getRaceId() {
        return raceId;
    }

    public void setRaceId(Integer raceId) {
        this.raceId = raceId;
    }


}

