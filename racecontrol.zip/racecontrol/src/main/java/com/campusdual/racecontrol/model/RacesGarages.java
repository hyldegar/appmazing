package com.campusdual.racecontrol.model;

import javax.persistence.*;

@Entity
@Table(name="RACES_GARAGES")
public class RacesGarages {

        @EmbeddedId
        private RacesGaragesId id;

        @ManyToOne
        @JoinColumn(name = "RACE_ID", insertable = false, updatable = false)
        private Race race;

        @ManyToOne
        @JoinColumn(name = "GARAGE_ID", insertable = false, updatable = false)
        private Garage garage;

    public RacesGaragesId getId() {
        return id;
    }

    public void setId(RacesGaragesId id) {
        this.id = id;
    }

    public Race getRace() {
        return race;
    }

    public void setRace(Race race) {
        this.race = race;
    }

    public Garage getGarage() {
        return garage;
    }

    public void setGarage(Garage garage) {
        this.garage = garage;
    }



}
