package com.campusdual.racecontrol.model.dao;

import com.campusdual.racecontrol.model.Race;
import org.springframework.data.jpa.repository.JpaRepository;

public interface RaceDao extends JpaRepository<Race,Integer> {
}
