package com.campusdual.racecontrol.api;

import com.campusdual.racecontrol.model.dto.TournamentDTO;

import java.util.List;

public interface ITournamentService {

    TournamentDTO queryTournament(TournamentDTO tournamentDTO);
    List<TournamentDTO> queryAllTournaments();

    int insertTournament(TournamentDTO tournamentDTO);
    int updateTournament(TournamentDTO tournamentDTO);
    int deleteTournament(TournamentDTO tournamentDTO);

}
