package com.campusdual.racecontrol.service;

import com.campusdual.racecontrol.api.IRacesGaragesService;
import com.campusdual.racecontrol.model.RacesGarages;
import com.campusdual.racecontrol.model.RacesGaragesId;
import com.campusdual.racecontrol.model.dao.RacesGaragesDao;
import com.campusdual.racecontrol.model.dto.RacesGaragesDTO;
import com.campusdual.racecontrol.model.dto.dtomapper.RacesGaragesMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Lazy;
import org.springframework.stereotype.Service;

import java.util.List;
@Service("RacesGaragesService")
@Lazy
public class RacesGaragesService implements IRacesGaragesService {
    @Autowired
    private RacesGaragesDao racesGaragesDao;
    @Override
    /*public RacesGaragesDTO queryRacesGarages(RacesGaragesDTO racesGaragesDTO) {
        RacesGarages racesGarages= RacesGaragesMapper.INSTANCE.toEntity(racesGaragesDTO);
        return RacesGaragesMapper.INSTANCE.toDTO(racesGaragesDao.getReferenceById(racesGarages.getId() ));
    }*/
    public RacesGaragesDTO queryRacesGarages(RacesGaragesDTO racesGaragesDTO) {
        RacesGaragesId racesGaragesId = new RacesGaragesId();
        racesGaragesId.setRaceId(racesGaragesDTO.getRaceId());
        racesGaragesId.setGarageId(racesGaragesDTO.getGarageId());

        RacesGarages racesGarages = racesGaragesDao.getReferenceById(racesGaragesId);

        return RacesGaragesMapper.INSTANCE.toDTO(racesGarages);
    }

    @Override
    public List<RacesGaragesDTO> queryAllRacesGarages() {
        return RacesGaragesMapper.INSTANCE.toDTOList(racesGaragesDao.findAll());
    }

    @Override
    public RacesGaragesId insertRacesGarages(RacesGaragesDTO racesGaragesDTO) {
        RacesGarages racesGarages= RacesGaragesMapper.INSTANCE.toEntity(racesGaragesDTO);
        racesGaragesDao.saveAndFlush(racesGarages);
        return racesGarages.getId();
    }

    @Override
    public RacesGaragesId updateRacesGarages(RacesGaragesDTO racesGaragesDTO) {
        return insertRacesGarages(racesGaragesDTO);
    }

    @Override
    public RacesGaragesId deleteRacesGarages(RacesGaragesDTO racesGaragesDTO) {
        RacesGarages racesGarages= RacesGaragesMapper.INSTANCE.toEntity(racesGaragesDTO);
        racesGaragesDao.delete(racesGarages);
        return racesGarages.getId();
    }
}
