package com.campusdual.racecontrol.model;

import javax.persistence.Column;
import javax.persistence.Embeddable;
import java.io.Serializable;

@Embeddable
public class RacesGaragesId implements Serializable {
    @Column(name = "RACE_ID")
    private Integer raceId;

    @Column(name = "GARAGE_ID")
    private Integer garageId;

    public Integer getRaceId() {
        return raceId;
    }

    public void setRaceId(Integer raceId) {
        this.raceId = raceId;
    }

    public Integer getGarageId() {
        return garageId;
    }

    public void setGarageId(Integer garageId) {
        this.garageId = garageId;
    }


}
