package com.campusdual.racecontrol.controller;

import com.campusdual.racecontrol.api.IRaceService;
import com.campusdual.racecontrol.model.dto.RaceDTO;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;
@RestController()
@CrossOrigin(origins = "http://localhost:4200", methods = {RequestMethod.GET, RequestMethod.POST, RequestMethod.PUT,
        RequestMethod.DELETE, RequestMethod.OPTIONS}, allowedHeaders = "*")
@RequestMapping("/races")
public class RaceController {
    @Autowired
    private IRaceService raceService;

    @GetMapping
    public String testRaceController(){
        return "Race Controller Works¡¡¡";
    }
    @PostMapping
    public String testCarController(@RequestBody String name){
        return "Race controller works, "+name+"!";
    }
    @PostMapping(value="/get")
    public RaceDTO queryRace(@RequestBody RaceDTO raceDTO){
        return  raceService.queryRace(raceDTO);
    }
    @GetMapping(value="/getAll")
    public List<RaceDTO> queryAllRaces(){
        return raceService.queryAllRaces();
    }
    @PostMapping(value="/add")
    public int addRace(@RequestBody RaceDTO raceDTO){
        return raceService.insertRace(raceDTO);
    }
    @PutMapping(value="/update")
    public int updateRace(@RequestBody RaceDTO raceDTO){
        return raceService.updateRace(raceDTO);
    }
    @PostMapping(value = "/delete")
    public int deleteRace(@RequestBody RaceDTO raceDTO){
        return raceService.deleteRace(raceDTO);
    }
}
