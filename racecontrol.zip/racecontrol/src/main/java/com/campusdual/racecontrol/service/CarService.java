package com.campusdual.racecontrol.service;

import com.campusdual.racecontrol.api.ICarService;
import com.campusdual.racecontrol.model.Car;
import com.campusdual.racecontrol.model.dao.CarDao;
import com.campusdual.racecontrol.model.dto.CarDTO;
import com.campusdual.racecontrol.model.dto.dtomapper.CarMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Lazy;
import org.springframework.stereotype.Service;

import java.util.List;

@Service("CarService")
@Lazy
public class CarService implements ICarService {
    @Autowired
    private CarDao carDao;

    @Override
    public CarDTO queryCar(CarDTO carDTO) {
        Car car = CarMapper.INSTANCE.toEntity(carDTO);
        return CarMapper.INSTANCE.toDTO(carDao.getReferenceById(car.getId()) );
    }
    @Override
    public List<CarDTO> queryAllCars() {
        return CarMapper.INSTANCE.toDTOList(carDao.findAll());
    }



    @Override
    public int insertCar(CarDTO carDTO) {
        Car car= CarMapper.INSTANCE.toEntity(carDTO);
        carDao.saveAndFlush(car);
        return car.getId();
    }

    @Override
    public int updateCar(CarDTO carDTO) {
        return insertCar(carDTO);
    }

    @Override
    public int deleteCar(CarDTO carDTO) {
        int id= carDTO .getId();
        Car car= CarMapper.INSTANCE.toEntity(carDTO);
        carDao.delete(car);
        return id;
    }
}
