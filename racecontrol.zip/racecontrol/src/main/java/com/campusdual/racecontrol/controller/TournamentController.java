package com.campusdual.racecontrol.controller;

import com.campusdual.racecontrol.api.ITournamentService;
import com.campusdual.racecontrol.model.dto.TournamentDTO;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController()
@CrossOrigin(origins = "http://localhost:4200", methods = {RequestMethod.GET, RequestMethod.POST, RequestMethod.PUT,
        RequestMethod.DELETE, RequestMethod.OPTIONS}, allowedHeaders = "*")
@RequestMapping("/tournaments")
public class TournamentController {
    @Autowired
    private ITournamentService tournamentService;

    @GetMapping
    public String testTournamentController(){
        return "Tournament Controller Works¡¡¡";
    }
    @PostMapping
    public String testCarController(@RequestBody String name){
        return "Tournament controller works, "+name+"!";
    }
    @PostMapping(value="/get")
    public TournamentDTO queryTournament(@RequestBody TournamentDTO tournamentDTO){
        return  tournamentService.queryTournament(tournamentDTO);
    }
    @GetMapping(value="/getAll")
    public List<TournamentDTO> queryAllTournaments(){
        return tournamentService.queryAllTournaments();
    }
    @PostMapping(value="/add")
    public int addTournament(@RequestBody TournamentDTO tournamentDTO){
        return tournamentService.insertTournament(tournamentDTO);
    }
    @PutMapping(value="/update")
    public int updateTournament(@RequestBody TournamentDTO tournamentDTO){
        return tournamentService.updateTournament(tournamentDTO);
    }
    @PostMapping(value = "/delete")
    public int deleteTournament(@RequestBody TournamentDTO tournamentDTO){
        return tournamentService.deleteTournament(tournamentDTO);
    }
}
