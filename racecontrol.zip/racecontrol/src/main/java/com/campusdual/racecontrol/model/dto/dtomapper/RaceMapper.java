package com.campusdual.racecontrol.model.dto.dtomapper;

import com.campusdual.racecontrol.model.Race;
import com.campusdual.racecontrol.model.dto.RaceDTO;
import org.mapstruct.Mapper;
import org.mapstruct.factory.Mappers;

import java.util.List;

@Mapper
public interface RaceMapper {
    RaceMapper INSTANCE= Mappers.getMapper(RaceMapper.class);
    RaceDTO toDTO (Race race);
    List<RaceDTO> toDTOList(List<Race> races);
    Race toEntity(RaceDTO racedto);


}
