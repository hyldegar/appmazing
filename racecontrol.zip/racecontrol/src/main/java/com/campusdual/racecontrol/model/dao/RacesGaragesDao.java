package com.campusdual.racecontrol.model.dao;

import com.campusdual.racecontrol.model.RacesGarages;
import com.campusdual.racecontrol.model.RacesGaragesId;
import org.springframework.data.jpa.repository.JpaRepository;

public interface RacesGaragesDao extends JpaRepository<RacesGarages,Integer> {
    RacesGarages getReferenceById(RacesGaragesId racesGaragesId);
}
