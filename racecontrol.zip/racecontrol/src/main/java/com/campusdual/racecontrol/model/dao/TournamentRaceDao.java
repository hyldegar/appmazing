package com.campusdual.racecontrol.model.dao;


import com.campusdual.racecontrol.model.TournamentRace;
import org.springframework.data.jpa.repository.JpaRepository;

public interface TournamentRaceDao extends JpaRepository<TournamentRace,Integer> {
}
