package com.campusdual.racecontrol.controller;

import com.campusdual.racecontrol.api.ICarService;
import com.campusdual.racecontrol.model.Car;
import com.campusdual.racecontrol.model.dto.CarDTO;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.stream.Collectors;

@RestController()
@CrossOrigin(origins = "http://localhost:4200", methods = {RequestMethod.GET, RequestMethod.POST, RequestMethod.PUT,
        RequestMethod.DELETE, RequestMethod.OPTIONS}, allowedHeaders = "*")
@RequestMapping("/cars")
public class CarController {
    @Autowired
    private ICarService carService;

    @GetMapping
    public String testCarController(){
        return "Car Controller Works¡¡¡";
    }
    @PostMapping
    public String testCarController(@RequestBody String name){
        return "Car controller works, "+name+"!";
    }
    @PostMapping(value="/get")
    public CarDTO queryCar(@RequestBody CarDTO carDTO){
        return  carService.queryCar(carDTO);
    }
    @GetMapping(value="/getAll")
    public List<CarDTO> queryAllCars(){
        return carService.queryAllCars();
    }

    @PostMapping(value="/add")
    public int addCar(@RequestBody CarDTO carDTO){
        return carService.insertCar(carDTO);
    }
    @PutMapping(value="/update")
    public int updateCar(@RequestBody CarDTO carDTO){
        return carService.updateCar(carDTO);
    }
    @PostMapping(value = "/delete")
    public int deleteCar(@RequestBody CarDTO carDTO){
        return carService.deleteCar(carDTO);
    }
}
