package com.campusdual.racecontrol.model.dao;

import com.campusdual.racecontrol.model.Garage;
import org.springframework.data.jpa.repository.JpaRepository;

public interface GarageDao extends JpaRepository<Garage, Integer> {
}
