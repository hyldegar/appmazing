package com.campusdual.racecontrol.api;

import com.campusdual.racecontrol.model.dto.RaceDTO;

import java.util.List;

public interface IRaceService {
    RaceDTO queryRace(RaceDTO raceDTO);
    List<RaceDTO> queryAllRaces();

    int insertRace (RaceDTO raceDTO);
    int updateRace(RaceDTO raceDTO);
    int deleteRace(RaceDTO raceDTO);
}
