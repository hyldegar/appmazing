package com.campusdual.racecontrol.model.dto.dtomapper;

import com.campusdual.racecontrol.model.Tournament;
import com.campusdual.racecontrol.model.dto.TournamentDTO;
import org.mapstruct.Mapper;
import org.mapstruct.factory.Mappers;

import java.util.List;

@Mapper
public interface TournamentMapper {
    TournamentMapper INSTANCE= Mappers.getMapper(TournamentMapper.class);
    TournamentDTO toDTO (Tournament tournament);
    List<TournamentDTO> toDTOList(List<Tournament> tournaments);
    Tournament toEntity(TournamentDTO tournamentdto);
    

}
