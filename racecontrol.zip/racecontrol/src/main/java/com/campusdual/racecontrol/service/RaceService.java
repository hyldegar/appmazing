package com.campusdual.racecontrol.service;

import com.campusdual.racecontrol.api.IRaceService;
import com.campusdual.racecontrol.model.Race;
import com.campusdual.racecontrol.model.dao.RaceDao;
import com.campusdual.racecontrol.model.dto.RaceDTO;
import com.campusdual.racecontrol.model.dto.dtomapper.RaceMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Lazy;
import org.springframework.stereotype.Service;

import java.util.List;

@Service("RaceService")
@Lazy
public class RaceService implements IRaceService {
    @Autowired
    private RaceDao raceDao;
    @Override
    public RaceDTO queryRace(RaceDTO raceDTO) {
        Race race= RaceMapper.INSTANCE.toEntity(raceDTO);
        return RaceMapper.INSTANCE.toDTO(raceDao.getReferenceById(race.getId() ));
    }

    @Override
    public List<RaceDTO> queryAllRaces() {
        return RaceMapper.INSTANCE.toDTOList(raceDao.findAll());
    }

    @Override
    public int insertRace(RaceDTO raceDTO) {
        Race race= RaceMapper.INSTANCE.toEntity(raceDTO);
        raceDao.saveAndFlush(race);
        return race.getId();
    }

    @Override
    public int updateRace(RaceDTO raceDTO) {
        return insertRace(raceDTO);
    }

    @Override
    public int deleteRace(RaceDTO raceDTO) {
        Race race= RaceMapper.INSTANCE.toEntity(raceDTO);
        raceDao.delete(race);
        return raceDTO.getId();
    }
}
