package com.campusdual.racecontrol.service;


import com.campusdual.racecontrol.api.ITournamentService;
import com.campusdual.racecontrol.model.Tournament;
import com.campusdual.racecontrol.model.dao.TournamentDao;
import com.campusdual.racecontrol.model.dto.TournamentDTO;
import com.campusdual.racecontrol.model.dto.dtomapper.TournamentMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Lazy;
import org.springframework.stereotype.Service;

import java.util.List;

@Service("TournamentService")
@Lazy
public class TournamentService implements ITournamentService {
    @Autowired
    private TournamentDao tournamentDao;
    @Override
    public TournamentDTO queryTournament(TournamentDTO tournamentDTO) {
        Tournament tournament= TournamentMapper.INSTANCE.toEntity(tournamentDTO);
        return TournamentMapper.INSTANCE.toDTO(tournamentDao.getReferenceById(tournament.getId()));
    }

    @Override
    public List<TournamentDTO> queryAllTournaments() {
        return TournamentMapper.INSTANCE.toDTOList(tournamentDao.findAll());
    }

    @Override
    public int insertTournament(TournamentDTO tournamentDTO) {
        Tournament tournament= TournamentMapper.INSTANCE.toEntity(tournamentDTO);
        tournamentDao.saveAndFlush(tournament);
        return tournament.getId();
    }

    @Override
    public int updateTournament(TournamentDTO tournamentDTO) {
        return insertTournament(tournamentDTO);
    }

    @Override
    public int deleteTournament(TournamentDTO tournamentDTO) {
        Tournament tournament= TournamentMapper.INSTANCE.toEntity(tournamentDTO);
        tournamentDao.delete(tournament);
        return tournamentDTO.getId();
    }
}
