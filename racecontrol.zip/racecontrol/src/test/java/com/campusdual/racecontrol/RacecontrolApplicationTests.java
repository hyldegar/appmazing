package com.campusdual.racecontrol;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RacecontrolApplicationTests {

	@Test
	void contextLoads() {
	}

}
